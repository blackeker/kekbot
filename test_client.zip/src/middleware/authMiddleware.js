const { getClient } = require('../services/botManager');

/**
 * Gelen istekleri doğrulayan Express ara yazılımı.
 * 'Authorization' başlığında geçerli bir API anahtarı bekler.
 * Başarılı olursa, ilgili Discord istemcisini 'req.discordClient' olarak ekler.
 * @param {object} req Express istek nesnesi.
 * @param {object} res Express yanıt nesnesi.
 * @param {function} next Bir sonraki ara yazılımı çağıran fonksiyon.
 */
async function authMiddleware(req, res, next) {
  // API anahtarını 'Authorization' veya 'x-api-key' başlığından al
  const apiKey = req.headers.authorization || req.headers['x-api-key'];

  if (!apiKey) {
    return res.status(401).json({ success: false, error: 'Yetkisiz: API anahtarı belirtilmedi.' });
  }

  try {
    // Bot yöneticisinden ilgili Discord istemcisini al
    const client = await getClient(apiKey);
    
    // İstemciyi sonraki işlemlerin erişebilmesi için istek nesnesine ekle
    req.discordClient = client;

    // Her şey yolundaysa, bir sonraki adıma geç
    next();
  } catch (error) {
    console.error(`Kimlik doğrulama hatası (API Key: ${apiKey}):`, error.message);
    // Hata durumunda yetkisiz hatası döndür
    return res.status(401).json({ success: false, error: `Yetkisiz: ${error.message}` });
  }
}

module.exports = authMiddleware;
