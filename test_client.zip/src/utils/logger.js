/**
 * Simple Logger Utility
 * Standardizes log format throughout the application.
 */

const log = (message, type = 'INFO') => {
    const timestamp = new Date().toISOString();
    let icon = 'ℹ️';
    
    switch (type) {
        case 'ERROR': icon = '❌'; break;
        case 'WARN': icon = '⚠️'; break;
        case 'SUCCESS': icon = '✅'; break;
        case 'DEBUG': icon = '🐛'; break;
    }

    console.log(`[${timestamp}] ${icon} [${type}] ${message}`);
};

const info = (msg) => log(msg, 'INFO');
const error = (msg) => log(msg, 'ERROR');
const warn = (msg) => log(msg, 'WARN');
const success = (msg) => log(msg, 'SUCCESS');

module.exports = { log, info, error, warn, success };
