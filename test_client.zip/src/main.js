const { createApiServer } = require('./api');
const { info, error } = require('./utils/logger');

// ASCII Banner
console.log(`
╔════════════════════════════════════════════════════════════════════════════════════════════════╗
║                                                                                                ║
║    ██████╗ ██╗      █████╗  ██████╗██╗  ██╗███████╗██╗  ██╗███████╗██████╗                     ║
║    ██╔══██╗██║     ██╔══██╗██╔════╝██║ ██╔╝██╔════╝██║ ██╔╝██╔════╝██╔══██╗                    ║
║    ██████╔╝██║     ███████║██║     █████╔╝ █████╗  █████╔╝ █████╗  ██████╔╝                    ║
║    ██╔══██╗██║     ██╔══██║██║     ██╔═██╗ ██╔══╝  ██╔═██╗ ██╔══╝  ██╔══██╗                    ║
║    ██████╔╝███████╗██║  ██║╚██████╗██║  ██╗███████╗██║  ██╗███████╗██║  ██╗                    ║
║    ╚═════╝ ╚══════╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝                    ║
║                                                                                                ║
║                       Discord Bot - Multi-User REST API v2.1                                   ║
║                                                                                                ║
╚════════════════════════════════════════════════════════════════════════════════════════════════╝
`);

info('🚀 Blackeker Discord Bot API başlatılıyor...');
info('📦 Çoklu kullanıcı desteği aktif (SQLite)');
info('🔐 Korumalı API uç noktaları hazır');

// Start API Server
try {
    createApiServer();
} catch (err) {
    error(`❌ FATAL: API sunucusu başlatılamadı: ${err.message}`);
    process.exit(1);
}

// Graceful shutdown
process.on('SIGINT', () => {
    info('🛑 Uygulama kapatılıyor...');
    process.exit(0);
});

process.on('SIGTERM', () => {
    info('🛑 Uygulama kapatılıyor...');
    process.exit(0);
});
