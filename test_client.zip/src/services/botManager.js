const { Client } = require('discord.js-selfbot-v13');
const { getUserByApiKey, getUserCommands, getUserSettings, saveBotState, getBotState } = require('./databaseService');

const activeClients = new Map();
// Anahtar: apiKey, Değer: Array<IntervalID>
const activeIntervals = new Map();

const fetch = require('node-fetch'); // node-fetch gerekebilir, yoksa axios kullanırız. native fetch v18+ var.
// Node 18+ ise global fetch kullanabiliriz. Güvenli olsun diye native https kullanalım ya da axios.
// Projede axios yoksa native https kullanırız.
const https = require('https');

function downloadImageToBase64(url) {
  return new Promise((resolve, reject) => {
    https.get(url, (res) => {
      const data = [];
      res.on('data', (chunk) => data.push(chunk));
      res.on('end', () => {
        const buffer = Buffer.concat(data);
        const base64 = buffer.toString('base64');
        resolve(base64);
      });
    }).on('error', (err) => {
      reject(err);
    });
  });
}

/**
 * Verilen API anahtarı için bir Discord istemcisi döndürür.
 * İstemci zaten aktifse, mevcut olanı döndürür.
 * Değilse, yeni bir tane oluşturur, giriş yapar ve saklar.
 * @param {string} apiKey Kullanıcının API anahtarı.
 * @returns {Promise<Client>} Kullanıcıya ait Discord istemci nesnesi.
 */
async function getClient(apiKey) {
  // 1. İstemci zaten aktif mi diye kontrol et
  if (activeClients.has(apiKey)) {
    console.log(`Mevcut istemci kullanılıyor: ${apiKey}`);
    return activeClients.get(apiKey);
  }

  // 2. İstemci aktif değilse, veritabanından kullanıcıyı al
  console.log(`Yeni istemci oluşturuluyor: ${apiKey}`);
  const user = await getUserByApiKey(apiKey);

  if (!user || !user.discordToken) {
    throw new Error('Geçersiz API anahtarı veya kullanıcı bulunamadı.');
  }

  // 3. Yeni bir istemci oluştur ve giriş yap
  const client = new Client({
    checkUpdate: false, // Otomatik güncelleme kontrolünü kapatabiliriz
  });

  return new Promise((resolve, reject) => {
    client.on('ready', () => {
      console.log(`${client.user.username} olarak giriş yapıldı! API Key: ${apiKey}`);
      activeClients.set(apiKey, client);

      // Otomatik Mesajları Başlat
      startAutoMessages(apiKey, client);

      // Dinleyici ekle
      client.on('messageCreate', async (message) => {
        const content = message.content || '';
        if (content.includes('STOP USING THIS COMMAND OR YOU WILL GET BLACKLISTED') &&
          content.includes('complete the captcha using')) {

          console.log(`⚠️ CAPTCHA DETECTED for user ${client.user.username}`);

          let imageBase64 = null;
          // Ekli resim var mı?
          if (message.attachments.size > 0) {
            const attachment = message.attachments.first();
            if (attachment.contentType && attachment.contentType.startsWith('image/')) {
              try {
                imageBase64 = await downloadImageToBase64(attachment.url);
                console.log('Captcha image downloaded.');
              } catch (err) {
                console.error('Failed to download captcha image:', err);
              }
            }
          }

          // Durumu veritabanına kaydet
          saveBotState(client.user.id, true, imageBase64);
        } else if (content.includes('captcha completed, you can keep playing!') &&
          message.mentions.users.has(client.user.id)) {
          // Captcha çözüldü!
          console.log(`✅ CAPTCHA SOLVED for user ${client.user.username}`);
          saveBotState(client.user.id, false, null);
        } else if (content.startsWith('+captcha') && message.author.id === client.user.id) {
        }
      });

      resolve(client);
    });

    client.login(user.discordToken).catch(err => {
      console.error(`Token ile giriş yapılamadı. API Key: ${apiKey}`, err);
      activeClients.delete(apiKey); // Başarısız girişişte istemciyi temizle
      reject(new Error('Discord\'a giriş yapılamadı. Token geçersiz olabilir.'));
    });
  });
}

/**
 * Bir istemciyi durdurur ve aktif listeden kaldırır.
 * (Örn: Kullanıcı hesabını sildiğinde kullanılabilir)
 * @param {string} apiKey Durdurulacak istemcinin API anahtarı.
 */
function stopClient(apiKey) {
  if (activeClients.has(apiKey)) {
    const client = activeClients.get(apiKey);
    client.destroy();
    activeClients.delete(apiKey);
    stopAutoMessages(apiKey);
    console.log(`İstemci durduruldu ve listeden kaldırıldı: ${apiKey}`);
  }
}

module.exports = {
  getClient,
  stopClient,
  getCaptchaState: (apiKey) => {
    // API Key'den User ID bulup DB'den çekmemiz lazım, ama client aktifse user.id var
    // Client aktif değilse bile DB'den okuyabilmek için apiKey -> userId dönüşümü gerek
    const client = activeClients.get(apiKey);
    if (client) {
      return getBotState(client.user.id);
    }
    return { active: false, imageBase64: null }; // Client yoksa varsayılan dön
  },
  restartAutoMessages: async (apiKey) => {
    const client = activeClients.get(apiKey);
    if (client) {
      await startAutoMessages(apiKey, client);
    }
  }
};

/**
 * Kullanıcı için otomatik mesaj zamanlayıcılarını başlatır.
 * @param {string} apiKey 
 * @param {Client} client 
 */
async function startAutoMessages(apiKey, client) {
  // Önce eskileri temizle
  stopAutoMessages(apiKey);

  try {
    const settings = await getUserSettings(client.user.id);
    const commands = await getUserCommands(client.user.id);

    if (!settings.channelId) {
      console.log(`AutoMessages: Channel ID not set for ${client.user.id}`);
      return;
    }

    const intervals = [];

    commands.forEach(cmd => {
      const intervalMs = parseInt(cmd.interval);
      if (!isNaN(intervalMs) && intervalMs > 0) {
        console.log(`Starting auto-message: "${cmd.trigger}" every ${intervalMs}ms`);

        const timer = setInterval(async () => {
          // Captcha Kontrolü (DB'den)
          const cap = getBotState(client.user.id);
          if (cap && cap.active) {
            console.log(`Skipping auto-message ("${cmd.trigger}") due to CAPTCHA LOCK.`);
            return;
          }

          try {
            const channel = await client.channels.fetch(settings.channelId);
            if (channel) {
              await channel.send(cmd.text);
              console.log(`Auto-message sent: ${cmd.trigger}`);
            }
          } catch (err) {
            console.error(`Auto-message error (${cmd.trigger}): ${err.message}`);
          }
        }, intervalMs);

        intervals.push(timer);
      }
    });

    if (intervals.length > 0) {
      activeIntervals.set(apiKey, intervals);
    }

  } catch (error) {
    console.error(`Error starting auto-messages: ${error.message}`);
  }
}

function stopAutoMessages(apiKey) {
  if (activeIntervals.has(apiKey)) {
    activeIntervals.get(apiKey).forEach(clearInterval);
    activeIntervals.delete(apiKey);
    console.log(`Stopped auto-messages for ${apiKey}`);
  }
}
