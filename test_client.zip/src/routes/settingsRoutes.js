const express = require('express');
const router = express.Router();
const { getUserSettings } = require('../services/databaseService');
const { info, error } = require('../utils/logger');

// Get Settings
router.get('/', async (req, res) => {
    try {
        const client = req.discordClient;
        const userId = client.user.id;

        const settings = await getUserSettings(userId);
        info(`Settings retrieved key for user: ${client.user.username}`);
        res.json({ success: true, data: settings });
    } catch (e) {
        error(`Error retrieving settings: ${e.message}`);
        res.status(500).json({ success: false, error: e.message });
    }
});

// Settings import/export/rpc placeholders
router.post('/rpc', (req, res) => res.status(501).json({ success: false, error: 'Not implemented' }));
router.post('/gems', (req, res) => res.status(501).json({ success: false, error: 'Not implemented' }));
router.get('/export', (req, res) => res.status(501).json({ success: false, error: 'Not implemented' }));
router.post('/import', (req, res) => res.status(501).json({ success: false, error: 'Not implemented' }));

module.exports = router;
