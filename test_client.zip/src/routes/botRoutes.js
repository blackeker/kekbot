const express = require('express');
const router = express.Router();
const {
    getUserCommands, saveUserCommands, addUserCommand,
    updateUserCommand, patchUserCommand, deleteUserCommand,
    saveUserSettings, getUserSettings
} = require('../services/databaseService');
const { stopClient, getCaptchaState, restartAutoMessages } = require('../services/botManager');
const { info, error } = require('../utils/logger');

// Helper to handle async errors? (We're doing try-catch for now)

// Status
router.get('/status', (req, res) => {
    const client = req.discordClient;
    if (!client || !client.user) {
        return res.status(500).json({ success: false, error: 'Discord client not ready.' });
    }
    res.json({
        success: true,
        data: {
            username: client.user.username,
            id: client.user.id,
            isReady: client.isReady(),
        },
        captchaState: getCaptchaState(req.headers.authorization || req.headers['x-api-key'])
    });
});


// Start (Actually just checks if running because middleware ensures it's running)
router.post('/start', (req, res) => {
    const client = req.discordClient;
    info(`Bot start check: ${client.user.username}`);
    res.json({ success: true, message: 'Bot başarıyla başlatıldı (veya zaten çalışıyordu).' });
});

// Stop
router.post('/stop', (req, res) => {
    const apiKey = req.headers.authorization || req.headers['x-api-key'];
    try {
        stopClient(apiKey);
        info(`Bot stopped: ${req.discordClient.user.username}`);
        res.json({ success: true, message: 'Bot durduruldu.' });
    } catch (e) {
        error(`Error stopping bot: ${e.message}`);
        res.status(500).json({ success: false, error: 'Bot durdurulurken hata.' });
    }
});

// Send Message
router.post('/send-message', async (req, res) => {
    const { channelId, message } = req.body;
    const client = req.discordClient;
    const apiKey = req.headers.authorization || req.headers['x-api-key'];

    // Captcha kontrolü
    const captcha = getCaptchaState(apiKey);
    if (captcha.active) {
        return res.status(423).json({
            success: false,
            error: 'LOCKED: Captcha required. Solve it first.',
            captchaRequired: true
        });
    }

    if (!channelId || !message) return res.status(400).json({ success: false, error: 'Missing channelId or message.' });

    try {
        const channel = await client.channels.fetch(channelId);
        if (!channel || typeof channel.send !== 'function') {
            return res.status(400).json({ success: false, error: 'Invalid channel or cannot send.' });
        }
        await channel.send(message);
        info(`Message sent to ${channelId} by ${client.user.username}`);
        res.json({ success: true, message: 'Mesaj gönderildi.' });
    } catch (e) {
        error(`Send message error: ${e.message}`);
        res.status(500).json({ success: false, error: e.message });
    }
});

// Settings (Update)
router.post('/settings', async (req, res) => {
    try {
        const client = req.discordClient;
        const userId = client.user.id;
        const { channelId, theme, gemSystemEnabled, gems, rpcEnabled, rpcSettings } = req.body;

        const settings = {};
        if (channelId !== undefined) settings.channelId = channelId;
        if (theme !== undefined) settings.theme = theme;
        if (typeof gemSystemEnabled === 'boolean') settings.gemSystemEnabled = gemSystemEnabled;
        if (Array.isArray(gems)) settings.gems = gems;
        if (typeof rpcEnabled === 'boolean') settings.rpcEnabled = rpcEnabled;
        if (rpcSettings) settings.rpcSettings = rpcSettings;

        await saveUserSettings(userId, settings);
        const current = await getUserSettings(userId);

        // Settings değiştiği için (Channel ID olabilir) otomasyonu yenile
        const apiKey = req.headers.authorization || req.headers['x-api-key'];
        await restartAutoMessages(apiKey);

        info(`Settings updated for ${client.user.username}`);
        res.json({ success: true, message: 'Ayarlar güncellendi', data: current });
    } catch (e) {
        error(`Settings update error: ${e.message}`);
        res.status(400).json({ success: false, error: e.message });
    }
});

// Commands - GET
router.get('/commands', async (req, res) => {
    try {
        const cmds = await getUserCommands(req.discordClient.user.id);
        res.json({ success: true, data: cmds });
    } catch (e) {
        error(`Get commands error: ${e.message}`);
        res.status(500).json({ success: false, error: e.message });
    }
});

// Commands - POST (Bulk Update)
router.post('/commands', async (req, res) => {
    const { commands } = req.body;
    if (!Array.isArray(commands)) return res.status(400).json({ success: false, error: 'commands array required' });

    try {
        await saveUserCommands(req.discordClient.user.id, commands);

        // Komutlar değişti, otomasyonu yenile
        const apiKey = req.headers.authorization || req.headers['x-api-key'];
        await restartAutoMessages(apiKey);

        res.json({ success: true, data: commands });
    } catch (e) {
        res.status(500).json({ success: false, error: e.message });
    }
});

// Commands - Add
router.post('/commands/add', async (req, res) => {
    const { command } = req.body;
    if (!command || !command.text) return res.status(400).json({ success: false, error: 'Invalid command object' });
    try {
        const updated = await addUserCommand(req.discordClient.user.id, command);

        // Yeni komut eklendi (interval olabilir), otomasyonu yenile
        const apiKey = req.headers.authorization || req.headers['x-api-key'];
        await restartAutoMessages(apiKey);

        res.json({ success: true, data: updated });
    } catch (e) {
        res.status(500).json({ success: false, error: e.message });
    }
});

// Commands - Update/Delete/Patch by Index
router.put('/commands/:index', async (req, res) => handleCommandUpdate(req, res, updateUserCommand));
router.patch('/commands/:index', async (req, res) => handleCommandUpdate(req, res, patchUserCommand));

async function handleCommandUpdate(req, res, fn) {
    const idx = parseInt(req.params.index);
    const data = req.body.command || req.body; // .command for full update, body for patch
    if (isNaN(idx)) return res.status(400).json({ success: false, error: 'Invalid index' });
    try {
        const updated = await fn(req.discordClient.user.id, idx, data);

        // Komut değişti, otomasyonu yenile
        const apiKey = req.headers.authorization || req.headers['x-api-key'];
        await restartAutoMessages(apiKey);

        res.json({ success: true, data: updated });
    } catch (e) {
        res.status(400).json({ success: false, error: e.message });
    }
}

router.delete('/commands/:index', async (req, res) => {
    const idx = parseInt(req.params.index);
    if (isNaN(idx)) return res.status(400).json({ success: false, error: 'Invalid index' });
    try {
        const updated = await deleteUserCommand(req.discordClient.user.id, idx);

        // Komut silindi, otomasyonu yenile
        const apiKey = req.headers.authorization || req.headers['x-api-key'];
        await restartAutoMessages(apiKey);

        res.json({ success: true, data: updated });
    } catch (e) {
        res.status(400).json({ success: false, error: e.message });
    }
});

module.exports = router;
