# Blackeker (Buapi) Native Android App Development Prompt

Sen dünyanın en iyi **Android (Kotlin)** ve **Mobile UI/UX** uzmanısın. Görevin, aşağıda detayları verilen "Blackeker" (Buapi) projesi için profesyonel, "Cyberpunk/Dark" temalı ve full-fonksiyonel bir **Native Android** uygulaması geliştirmektir.

Bu prompt, Android Studio'da geliştirilecek projenin mimarisini, kütüphanelerini, tasarım kurallarını ve API entegrasyon detaylarını içerir.

---

## 1. Proje Özeti ve Amacı

**Proje Adı:** Blackeker Mobile
**Platform:** Native Android (Min SDK 26)
**IDE:** Android Studio
**Dil:** Kotlin
**UI Toolkit:** Jetpack Compose (Modern UI)
**Tema:** "Blackeker Aesthetic" -> Koyu (Dark) mod, Neon Mor/Yeşil detaylar, Cyberpunk esintileri.

---

## 2. Teknik Gereksinimler (Tech Stack)

Aşağıdaki teknolojileri KESİNLİKLE kullanmalısın:

1.  **Dil:** Kotlin (100%)
2.  **UI:** Jetpack Compose (Material 3)
3.  **Networking:** Retrofit + OkHttp (Interceptor ile API Key yönetimi) + Gson/Moshi
4.  **Asenkron İşlemler:** Coroutines + Flow
5.  **Dependency Injection:** Hilt veya Manuel DI (Proje boyutuna göre basit tutulabilir)
6.  **Navigation:** Compose Navigation
7.  **Local Storage:** EncryptedSharedPreferences (API Key güvenliği için)
8.  **Architecture:** MVVM (Model-View-ViewModel)

---

## 3. API Entegrasyonu (Endpoints)

Base URL dinamik olmalı (Kullanıcı giriş ekranında belirleyebilmeli).

### 🔐 Auth & Başlangıç
*   **POST** `/register` -> Body: `{ "token": "..." }` -> Response: `{ "apiKey": "..." }`
    *   *İşlem:* Dönen `apiKey` cihazda şifreli saklanacak.
*   **GET** `/bot/status` -> Header: `x-api-key` -> Response: `{ "data": { "isReady": true, ... } }`

### 🤖 Kontrol
*   **POST** `/bot/start` -> Botu başlatır.
*   **POST** `/bot/stop` -> Botu durdurur.

### 💬 Mesajlaşma
*   **POST** `/bot/send-message` -> Body: `{ "channelId": "...", "message": "..." }`

### ⚙️ Ayarlar & Komutlar
*   **GET/POST** `/bot/settings` -> Ayarları okuma/yazma.
*   **GET/POST/DELETE** `/bot/commands` -> Komut listesi yönetimi.

---

## 4. Ekranlar ve UI Akışı

### 4.1. Login Screen (Giriş)
*   **Tasarım:** Siyah arka plan, merkezde neon logo.
*   **Alanlar:**
    *   `Server URL` (Varsayılan: `http://10.0.2.2:3000/api`)
    *   `Discord Token` (Password field)
*   **Aksiyon:** "Bağlan" butonu -> Başarılı ise Dashboard'a git.

### 4.2. Dashboard (Ana Ekran)
*   **Durum Paneli:** Ortada büyük bir durum halkası (Online/Offline/Locked).
*   **Otomasyon Durumu:** Aktif otomatik mesajların özeti.
*   **Kontroller:** "Start" ve "Stop" butonları.
*   **Navigasyon:** Alt bar (Bottom Navigation): `Home`, `Auto-Messages`, `Settings`.

### 4.3. Message Manager (Auto-Messages)
*   **Amaç:** Botun belirli aralıklarla kanala atacağı mesajları yönetmek.
*   **Liste:** `LazyColumn` içinde kartlar. Her kartta:
    *   Mesaj Başlığı (Referans)
    *   Mesaj İçeriği (Kısa görünüm)
    *   Döngü (Örn: "Her 30sn")
*   **Ekleme:** `FloatingActionButton` (+) ile dialog açılır.
    *   Alanlar: `Başlık`, `Mesaj İçeriği`, `Döngü Süresi (ms)`.
*   **Silme:** Sağa/sola kaydırarak silme.

### 4.4. Send Message (FAB veya Ayrı Ekran)
*   Kanal ID ve Mesaj metni girilen basit, şık bir form.

---

## 5. Tasarım Kuralları (Blackeker Theme)

*   **Renkler (`Color.kt`):**
    *   Background: `Color(0xFF121212)`
    *   Surface: `Color(0xFF1E1E1E)`
    *   Primary: `Color(0xFF00FF94)` (Neon Yeşil) veya `Color(0xFFBB86FC)` (Cyberpunk Mor)
    *   OnBackground: `Color(0xFFEEEEEE)`
*   **Şekiller:** Köşeli butonlar veya çok az yuvarlatılmış (4.dp).
*   **Efektler:** Butonlarda hafif "Glow" (gölge) efekti.

---

## 6. Kod Yapısı (Örnek)

```kotlin
// 1. API Servisi (Retrofit)
interface BotApi {
    @POST("register")
    suspend fun register(@Body request: RegisterRequest): Response<RegisterResponse>

    @GET("bot/status")
    suspend fun getStatus(): Response<StatusResponse>
}

// 2. Interceptor (API Key Ekleme)
class AuthInterceptor(private val apiKeyManager: ApiKeyManager) : Interceptor {
    override fun intercept(chain: Interceptor.Chain): okhttp3.Response {
        val apiKey = apiKeyManager.getApiKey()
        val request = chain.request().newBuilder()
            .apply { if (apiKey != null) addHeader("x-api-key", apiKey) }
            .build()
        return chain.proceed(request)
    }
}

// 3. UI Theme (Basic)
@Composable
fun BlackekerTheme(content: @Composable () -> Unit) {
    val darkColors = darkColorScheme(
        background = Color(0xFF121212),
        primary = Color(0xFF00FF94),
        surface = Color(0xFF1E1E1E)
    )
    MaterialTheme(colorScheme = darkColors, content = content)
}
```

---

## 7. Görev Listesi

1.  **Proje Kurulumu:** Boş bir "Empty Activity" projesi oluştur.
2.  **Dependencies:** `build.gradle.kts` dosyasına Retrofit, Navigation ve Icons kütüphanelerini ekle.
3.  **Data Layer:** API modellerini (data class) ve Retrofit servisini yaz.
4.  **UI Layer:** Ekranları (LoginScreen, HomeScreen) Composable fonksiyonlar olarak tasarla.
5.  **Logic:** ViewModel'leri bağla ve API isteklerini at.
6.  **Build:** APK çıktısı al (`Build > Build Bundle(s) / APK(s) > Build APK(s)`).

Bu yönergeleri kullanarak projeyi sıfırdan oluştur, kodları dosya dosya ver.
